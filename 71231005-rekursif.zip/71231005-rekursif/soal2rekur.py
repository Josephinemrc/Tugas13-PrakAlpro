def palindrom(string, index = 0):
    string = string.lower()
    reversed_string = string[::-1]
    if index == len(string) - 1:
        if string[index] == reversed_string[index]:
            return f'"{string.capitalize()}" adalah Palindrome'
        else:
            return f'"{string.capitalize()}" bukan Palindrome'
    elif string[index] == reversed_string[index]:
        return palindrom(string, index + 1)
    else:
        return f'"{string.capitalize()}" bukan Palindrome'

print(palindrom("Malam"))
print(palindrom("siang"))

