def cek_prima(angka, i=2):
    if angka < 2:
        return f"{angka} bukan bilangan Prima"
    if i == angka:
        return f"{angka} adalah bilangan Prima"
    elif angka % i == 0:
        return f"{angka} bukan bilangan Prima"
    else:
        return cek_prima(angka, i + 1)

print(cek_prima(2))
print(cek_prima(7))

