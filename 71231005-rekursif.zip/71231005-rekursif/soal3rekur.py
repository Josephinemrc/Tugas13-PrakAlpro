def deret_ganjil(angka,total=set(),step=0):
    try:
      angka = int(angka)
      if angka < len(total):
          return deret_ganjil(angka,set(),0)
      elif len(total) == angka:
          return (sum(total))
      elif step % 2 == 0:
          return deret_ganjil(angka,total,step+1)
      else:
          total.add(step)
          return deret_ganjil(angka,total,step+1)
    except:
        return ("Maaf input yang diminta adalah angka")      
    
print (deret_ganjil(7))

