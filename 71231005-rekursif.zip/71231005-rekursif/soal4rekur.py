def jml_digit(angka,step=0,total=0):
    try:
      angka = int(angka)
      if step == ((len(str(angka)))-1):
          total += int(str(angka)[step])
          return total
      else:
          total += int(str(angka)[step])
          return jml_digit(angka,step+1,total)
    except:
        return ("input yang diminta adalah angka")      
    
print (jml_digit(567))

