def kombinasi(n, r, step_n=1, step_r=1, step_nr=1, total_n=1, total_r=1, total_nr=1):
    nr = n - r
    if step_n != n + 1:
        total_n *= step_n
        return kombinasi(n, r, step_n + 1, step_r, step_nr, total_n, total_r, total_nr)
    elif step_r != r + 1:
        total_r *= step_r
        return kombinasi(n, r, step_n, step_r + 1, step_nr, total_n, total_r, total_nr)
    elif step_nr != nr + 1:
        total_nr *= step_nr
        return kombinasi(n, r, step_n, step_r, step_nr + 1, total_n, total_r, total_nr)
    else:
        hasil = total_n / (total_r * total_nr)
        return hasil

print(int(kombinasi(8, 5)))

